package entities;

public class Operacion {
	
	private int oid_operacion;
	private int oid_tabla_periodica;
	private int oid_elemento;
	private int oid_usuario;
	
	public Operacion(int oid_operacion, int oid_tabla_periodica, int oid_elemento, int oid_usuario) {
		super();
		this.oid_operacion = oid_operacion;
		this.oid_tabla_periodica = oid_tabla_periodica;
		this.oid_elemento = oid_elemento;
		this.oid_usuario = oid_usuario;
	}

	public int getOid_operacion() {
		return oid_operacion;
	}

	public void setOid_operacion(int oid_operacion) {
		this.oid_operacion = oid_operacion;
	}

	public int getOid_tabla_periodica() {
		return oid_tabla_periodica;
	}

	public void setOid_tabla_periodica(int oid_tabla_periodica) {
		this.oid_tabla_periodica = oid_tabla_periodica;
	}

	public int getOid_elemento() {
		return oid_elemento;
	}

	public void setOid_elemento(int oid_elemento) {
		this.oid_elemento = oid_elemento;
	}

	public int getOid_usuario() {
		return oid_usuario;
	}

	public void setOid_usuario(int oid_usuario) {
		this.oid_usuario = oid_usuario;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + oid_elemento;
		result = prime * result + oid_operacion;
		result = prime * result + oid_tabla_periodica;
		result = prime * result + oid_usuario;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Operacion other = (Operacion) obj;
		if (oid_elemento != other.oid_elemento)
			return false;
		if (oid_operacion != other.oid_operacion)
			return false;
		if (oid_tabla_periodica != other.oid_tabla_periodica)
			return false;
		if (oid_usuario != other.oid_usuario)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Operacion [oid_operacion=" + oid_operacion + ", oid_tabla_periodica=" + oid_tabla_periodica
				+ ", oid_elemento=" + oid_elemento + ", oid_usuario=" + oid_usuario + "]";
	}
	
	

}
