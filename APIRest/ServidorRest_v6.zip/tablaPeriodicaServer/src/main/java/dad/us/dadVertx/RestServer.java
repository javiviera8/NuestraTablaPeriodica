package dad.us.dadVertx;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import com.github.mauricio.async.db.mysql.decoder.PreparedStatementPrepareResponseDecoder;
import com.google.gson.Gson;

import entities.Elemento;
import entities.Operacion;
import entities.TablaPeriodica;
import entities.Usuario;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.http.impl.pool.Pool;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.asyncsql.AsyncSQLClient;
import io.vertx.ext.asyncsql.MySQLClient;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;

public class RestServer extends AbstractVerticle {

	private AsyncSQLClient mySQLClient;
	
	public void start(Future<Void> startFuture) {
		
		JsonObject config = new JsonObject()
				.put("host", "localhost")
				.put("username", "root")
				.put("password", "root")
				.put("database", "tablaperiodicadb")
				.put("port", 3306);
		mySQLClient = MySQLClient.createShared(vertx, config);
		

		
		Router router = Router.router(vertx);
		vertx.createHttpServer().requestHandler(router)
			.listen(8090, result ->{
				if(result.succeeded()) {
					System.out.println("Servidor desplegado");
				}else {
					System.out.println("Error de despliegue");
				}
			});
		
		
		router.route().handler(BodyHandler.create());
		
		//GET
		router.get("/tablaperiodica").handler(this::handlerGetTablaPeriodica);
		router.get("/usuario").handler(this::handlerGetUsuario);
		router.get("/elemento").handler(this::handlerGetElemento);
		router.get("/operacion").handler(this::handlerGetOperacion);
		router.get("/elemento/:nombre_elemento").handler(this::handleProduct);
	
		//PUT
		router.put("/tablaperiodica").handler(this::handlerInsertTablaPeriodica);
		router.put("/usuario").handler(this::handlerInsertUsuario);
		router.put("/elemento").handler(this::handlerInsertElemento);
		router.put("/operacion").handler(this::handlerInsertOperacion);
		
		//POST
		router.post("/tablaperiodica").handler(this::handlerInsertTablaPeriodica);
		router.post("/usuario").handler(this::handlerInsertUsuario);
		router.post("/elemento").handler(this::handlerInsertElemento);
		router.post("/operacion").handler(this::handlerInsertOperacion);
		
		// Los dos puntos sirven para tratar una variable
		//router.put("/products/:productID/:property").handler(this::handleProductProperty);
	}
	
	//METODOS GET PARA REALIZAR LOS GET SOBRE CADA UNA DE LAS TABLAS DE LA BASE DE DATOS.
	private void handlerGetTablaPeriodica(RoutingContext routingConext) {
		mySQLClient.getConnection(connection -> {
			if (connection.succeeded()) {
				connection.result().query("SELECT * FROM tablaperiodica" , result -> {
					if (result.succeeded()) {
						
						try {
						Gson gson = new Gson();
						List<TablaPeriodica> tablasPeriodicas = new ArrayList<>();
						for(JsonObject json : result.result().getRows()) {
							tablasPeriodicas.add(gson.fromJson(json.encode(), TablaPeriodica.class));	
						}
						routingConext.response().end(gson.toJson(tablasPeriodicas));
						
						/*String jsonResult = new JsonArray(result.result().getRows()).encodePrettily();
						routingConext.response().end(jsonResult);*/
						}catch(Exception e) {
							System.out.println(e.getCause().getMessage());
							routingConext.response().setStatusCode(400).end();
						}
						
						connection.result().close();
						
					}else {
						System.out.println(result.cause().getMessage());
						routingConext.response().setStatusCode(400).end();
					}
				});
			}else {
				System.out.println(connection.cause().getMessage());
				routingConext.response().setStatusCode(400).end();
			}
		});
	}
	
	private void handlerGetUsuario(RoutingContext routingConext) {
		mySQLClient.getConnection(connection -> {
			if (connection.succeeded()) {
				connection.result().query("SELECT * FROM usuario" , result -> {
					if (result.succeeded()) {
						
						try {
						Gson gson = new Gson();
						List<Usuario> usuarios = new ArrayList<>();
						for(JsonObject json : result.result().getRows()) {
							usuarios.add(gson.fromJson(json.encode(), Usuario.class));	
						}
						
												routingConext.response().end(gson.toJson(usuarios));
						
						/*String jsonResult = new JsonArray(result.result().getRows()).encodePrettily();
						routingConext.response().end(jsonResult);*/
						}catch(Exception e){
							System.out.println(e.getCause().getMessage());
							routingConext.response().setStatusCode(400).end();
						}
						
						connection.result().close();
						
					}else {
						System.out.println(result.cause().getMessage());
						routingConext.response().setStatusCode(400).end();
					}
				});
			}else {
				System.out.println(connection.cause().getMessage());
				routingConext.response().setStatusCode(400).end();
			}
		});
	}
		
	private void handlerGetElemento(RoutingContext routingConext) {
		mySQLClient.getConnection(connection -> {
			if (connection.succeeded()) {
				connection.result().query("SELECT * FROM elemento" , result -> {
					if (result.succeeded()) {
						
						try {
							Gson gson = new Gson();
							List<Elemento> elementos = new ArrayList<>();
							for(JsonObject json : result.result().getRows()) {
								elementos.add(gson.fromJson(json.encode(), Elemento.class));
								
							}
							routingConext.response().end(gson.toJson(elementos));
							
							/*String jsonResult = new JsonArray(result.result().getRows()).encodePrettily();
							routingConext.response().end(jsonResult);*/
						}catch(Exception e){
							System.out.println(e.getCause().getMessage());
							routingConext.response().setStatusCode(400).end();
						}
					
						connection.result().close();
						
					}else {
						System.out.println(result.cause().getMessage());
						routingConext.response().setStatusCode(400).end();
					}
				});
			}else {
				System.out.println(connection.cause().getMessage());
				routingConext.response().setStatusCode(400).end();
			}
		});
	}
	private void handleProduct(RoutingContext routingContext) {
		String paramStr = routingContext.pathParam("nombre_elemento");
		JsonObject jsonObject = new JsonObject();
		jsonObject.put("nombre_elemento", paramStr);
		routingContext.response()
			.putHeader("content-type", "application/json")
			.end(jsonObject.encode());
	}
	private void handlerGetOperacion(RoutingContext routingConext) {
		mySQLClient.getConnection(connection -> {
			if (connection.succeeded()) {
				connection.result().query("SELECT * FROM operacion" , result -> {
					if (result.succeeded()) {
						
						try {
						Gson gson = new Gson();
						List<Operacion> operaciones = new ArrayList<>();
						for(JsonObject json : result.result().getRows()) {
							operaciones.add(gson.fromJson(json.encode(), Operacion.class));	
						}
						routingConext.response().end(gson.toJson(operaciones));
						
						/*String jsonResult = new JsonArray(result.result().getRows()).encodePrettily();
						routingConext.response().end(jsonResult);*/
						}catch(Exception e){
							System.out.println(e.getCause().getMessage());
							routingConext.response().setStatusCode(400).end();	
						}
						
						connection.result().close();
						
					}else {
						System.out.println(result.cause().getMessage());
						routingConext.response().setStatusCode(400).end();
					}
				});
			}else {
				System.out.println(connection.cause().getMessage());
				routingConext.response().setStatusCode(400).end();
			}
		});
	}
	
	//METODOS INSERT PARA REALIZAR LOS PUT/POST SOBRE CADA UNA DE LAS TABLAS DE LA BASE DE DATOS.
	private void handlerInsertTablaPeriodica(RoutingContext routingConext) {
		JsonObject body = routingConext.getBodyAsJson();
		routingConext.response().putHeader("content-type", "application/json").end(body.encode());
		
		mySQLClient.getConnection(connection -> {
			if (connection.succeeded()) {
				connection.result().query("INSERT INTO tablaperiodica() VALUES (" + ")", result -> {
					if(result.succeeded()) {
						System.out.println("INSERT realizado con éxito en la base de datos.");
					}else {
						System.out.println("INSERT no se pudo realizar con éxtio");
					}
					
					connection.result().close();
				});


			}else {
				System.out.println(connection.cause().getMessage());
				routingConext.response().setStatusCode(400).end();
			}
		});
	}
	
	private void handlerInsertUsuario(RoutingContext routingConext) {
		JsonObject body = routingConext.getBodyAsJson();
		routingConext.response().putHeader("content-type", "application/json").end(body.encode());
		
		mySQLClient.getConnection(connection -> {
			if (connection.succeeded()) {
				connection.result().query("INSERT INTO usuario(nombre,oid_tabla_periodica) VALUES ('" + body.getString("nombre") + "'," + body.getInteger("oid_tabla_periodica") + ")", result -> {
					if(result.succeeded()) {
						System.out.println("INSERT realizado con éxito en la base de datos.");
					}else {
						System.out.println("INSERT no se pudo realizar con éxtio");
					}
					
					connection.result().close();
				});


			}else {
				System.out.println(connection.cause().getMessage());
				routingConext.response().setStatusCode(400).end();
			}
		});
	}
	
	private void handlerInsertElemento(RoutingContext routingConext) {
		JsonObject body = routingConext.getBodyAsJson();
		routingConext.response().putHeader("content-type", "application/json").end(body.encode());
		
		mySQLClient.getConnection(connection -> {
			if (connection.succeeded()) {
				connection.result().query("INSERT INTO elemento(nombre_elemento,simbolo_elemento,numero_atomico,url_video,oid_tabla_periodica) VALUES ('" + body.getString("nombre_elemento")
				+ "','" + body.getString("simbolo_elemento") + "'," + body.getInteger("numero_atomico") + ",'" + body.getString("url_video") + "'," + body.getInteger("oid_tabla_periodica") + ")", result -> {
					if(result.succeeded()) {
						System.out.println("INSERT realizado con éxito en la base de datos.");
					}else {
						System.out.println("INSERT no se pudo realizar con éxtio");
					}
					
					connection.result().close();
				});


			}else {
				System.out.println(connection.cause().getMessage());
				routingConext.response().setStatusCode(400).end();
			}
		});
	}
	
	private void handlerInsertOperacion(RoutingContext routingConext) {
		JsonObject body = routingConext.getBodyAsJson();
		routingConext.response().putHeader("content-type", "application/json").end(body.encode());
		
		mySQLClient.getConnection(connection -> {
			if (connection.succeeded()) {
				connection.result().query("INSERT INTO operacion(oid_tabla_periodica,oid_elemento,oid_usuario) VALUES (" + body.getInteger("oid_tabla_periodica") 
				+ "," +  body.getInteger("oid_elemento") + "," + body.getInteger("oid_usuario") + ")", result -> {
					if(result.succeeded()) {
						System.out.println("INSERT realizado con éxito en la base de datos.");
					}else {
						System.out.println("INSERT no se pudo realizar con éxtio");
					}
					
					connection.result().close();
				});


			}else {
				System.out.println(connection.cause().getMessage());
				routingConext.response().setStatusCode(400).end();
			}
		});
	}
	
}
