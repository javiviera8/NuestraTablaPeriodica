package entities;

public class Operacion {
	
	private int idOperacion;
	private String elementoSolicitado;
	private long fecha;
	public Operacion(int idOperacion, String elementoSolicitado, long fecha) {
		super();
		this.idOperacion = idOperacion;
		this.elementoSolicitado = elementoSolicitado;
		this.fecha = fecha;
	}
	public Operacion() {
		super();
	}
	public int getIdOperacion() {
		return idOperacion;
	}
	public void setIdOperacion(int idOperacion) {
		this.idOperacion = idOperacion;
	}
	public String getElementoSolicitado() {
		return elementoSolicitado;
	}
	public void setElementoSolicitado(String elementoSolicitado) {
		this.elementoSolicitado = elementoSolicitado;
	}
	public long getFecha() {
		return fecha;
	}
	public void setFecha(long fecha) {
		this.fecha = fecha;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((elementoSolicitado == null) ? 0 : elementoSolicitado.hashCode());
		result = prime * result + (int) (fecha ^ (fecha >>> 32));
		result = prime * result + idOperacion;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Operacion other = (Operacion) obj;
		if (elementoSolicitado == null) {
			if (other.elementoSolicitado != null)
				return false;
		} else if (!elementoSolicitado.equals(other.elementoSolicitado))
			return false;
		if (fecha != other.fecha)
			return false;
		if (idOperacion != other.idOperacion)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Operacion [idOperacion=" + idOperacion + ", elementoSolicitado=" + elementoSolicitado + ", fecha="
				+ fecha + "]";
	}
	
	

}
