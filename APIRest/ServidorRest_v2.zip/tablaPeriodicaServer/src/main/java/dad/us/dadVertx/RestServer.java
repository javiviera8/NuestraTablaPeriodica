package dad.us.dadVertx;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;

import entities.Elemento;
import entities.Operacion;
import entities.TablaPeriodica;
import entities.Usuario;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.asyncsql.AsyncSQLClient;
import io.vertx.ext.asyncsql.MySQLClient;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;

public class RestServer extends AbstractVerticle {

	private AsyncSQLClient mySQLClient;
	
	public void start(Future<Void> startFuture) {
		
		JsonObject config = new JsonObject()
				.put("host", "localhost")
				.put("username", "root")
				.put("password", "root")
				.put("database", "tablaperiodica_db")
				.put("port", 3306);
		mySQLClient = MySQLClient.createShared(vertx, config);
		

		
		Router router = Router.router(vertx);
		vertx.createHttpServer().requestHandler(router)
			.listen(8090, result ->{
				if(result.succeeded()) {
					System.out.println("Servidor desplegado");
				}else {
					System.out.println("Error de despliegue");
				}
			});
		router.route().handler(BodyHandler.create());
		router.get("/elemento").handler(this::handlerElemento);
		router.get("/operacion").handler(this::handlerOperacion);
		router.get("/tablaperiodica").handler(this::handlerTablaPeriodica);
		router.get("/usuario").handler(this::handlerUsuario);
		router.get("/products/:productID/info").handler(this::handleProduct);// Los dos puntos sirven para tratar una variable
		router.put("/products/:productID/:property").handler(this::handleProductProperty);
	}
	
	private void handlerElemento(RoutingContext routingConext) {
		mySQLClient.getConnection(connection -> {
			if (connection.succeeded()) {
				connection.result().query("SELECT * FROM elemento" , result -> {
					if (result.succeeded()) {
						Gson gson = new Gson();
						List<Elemento> elementos = new ArrayList<>();
						for(JsonObject json : result.result().getRows()) {
							elementos.add(gson.fromJson(json.encode(), Elemento.class));	
						}
						routingConext.response().end(gson.toJson(elementos));
						
						/*String jsonResult = new JsonArray(result.result().getRows()).encodePrettily();
						routingConext.response().end(jsonResult);*/
					}else {
						System.out.println(result.cause().getMessage());
						routingConext.response().setStatusCode(400).end();
					}
				});
			}else {
				System.out.println(connection.cause().getMessage());
				routingConext.response().setStatusCode(400).end();
			}
		});
	}
	
	private void handlerOperacion(RoutingContext routingConext) {
		mySQLClient.getConnection(connection -> {
			if (connection.succeeded()) {
				connection.result().query("SELECT * FROM operacion" , result -> {
					if (result.succeeded()) {
						Gson gson = new Gson();
						List<Operacion> operaciones = new ArrayList<>();
						for(JsonObject json : result.result().getRows()) {
							operaciones.add(gson.fromJson(json.encode(), Operacion.class));	
						}
						routingConext.response().end(gson.toJson(operaciones));
						
						/*String jsonResult = new JsonArray(result.result().getRows()).encodePrettily();
						routingConext.response().end(jsonResult);*/
					}else {
						System.out.println(result.cause().getMessage());
						routingConext.response().setStatusCode(400).end();
					}
				});
			}else {
				System.out.println(connection.cause().getMessage());
				routingConext.response().setStatusCode(400).end();
			}
		});
	}
	
	private void handlerTablaPeriodica(RoutingContext routingConext) {
		mySQLClient.getConnection(connection -> {
			if (connection.succeeded()) {
				connection.result().query("SELECT * FROM tablaPeriodica" , result -> {
					if (result.succeeded()) {
						Gson gson = new Gson();
						List<TablaPeriodica> tablasPeriodicas = new ArrayList<>();
						for(JsonObject json : result.result().getRows()) {
							tablasPeriodicas.add(gson.fromJson(json.encode(), TablaPeriodica.class));	
						}
						routingConext.response().end(gson.toJson(tablasPeriodicas));
						
						/*String jsonResult = new JsonArray(result.result().getRows()).encodePrettily();
						routingConext.response().end(jsonResult);*/
					}else {
						System.out.println(result.cause().getMessage());
						routingConext.response().setStatusCode(400).end();
					}
				});
			}else {
				System.out.println(connection.cause().getMessage());
				routingConext.response().setStatusCode(400).end();
			}
		});
	}

	private void handlerUsuario(RoutingContext routingConext) {
		mySQLClient.getConnection(connection -> {
			if (connection.succeeded()) {
				connection.result().query("SELECT * FROM usuario" , result -> {
					if (result.succeeded()) {
						Gson gson = new Gson();
						List<Usuario> usuarios = new ArrayList<>();
						for(JsonObject json : result.result().getRows()) {
							usuarios.add(gson.fromJson(json.encode(), Usuario.class));	
						}
						routingConext.response().end(gson.toJson(usuarios));
						
						/*String jsonResult = new JsonArray(result.result().getRows()).encodePrettily();
						routingConext.response().end(jsonResult);*/
					}else {
						System.out.println(result.cause().getMessage());
						routingConext.response().setStatusCode(400).end();
					}
				});
			}else {
				System.out.println(connection.cause().getMessage());
				routingConext.response().setStatusCode(400).end();
			}
		});
	}
	
	private void handleProduct(RoutingContext routingContext) {
		String paramStr = routingContext.pathParam("productID");
		int paramInt = Integer.parseInt(paramStr);
		JsonObject jsonObject = new JsonObject();
		jsonObject.put("serial", "jlehflfhfdlfhdf");
		jsonObject.put("id", paramInt);
		jsonObject.put("name", "TV Samsung");
		routingContext.response().putHeader("content-type", "application/json").end(jsonObject.encode());
		
	}
	
	private void handleProductProperty(RoutingContext routingContext) {
		String paramStr = routingContext.pathParam("productID");
		int paramInt = Integer.parseInt(paramStr);
		JsonObject body = routingContext.getBodyAsJson();
		routingContext.response().putHeader("content-type", "application/json").end(body.encode());
		
	}
}
