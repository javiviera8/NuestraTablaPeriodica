package entities;

public class Usuario {
	
	private int oid_usuario;
	private String nombre;
	private int oid_tabla_periodica;
	
	public Usuario(int oid_usuario, String nombre, int oid_tabla_periodica) {
		super();
		this.oid_usuario = oid_usuario;
		this.nombre = nombre;
		this.oid_tabla_periodica = oid_tabla_periodica;
	}

	public int getOid_usuario() {
		return oid_usuario;
	}

	public void setOid_usuario(int oid_usuario) {
		this.oid_usuario = oid_usuario;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getOid_tabla_periodica() {
		return oid_tabla_periodica;
	}

	public void setOid_tabla_periodica(int oid_tabla_periodica) {
		this.oid_tabla_periodica = oid_tabla_periodica;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		result = prime * result + oid_tabla_periodica;
		result = prime * result + oid_usuario;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Usuario other = (Usuario) obj;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		if (oid_tabla_periodica != other.oid_tabla_periodica)
			return false;
		if (oid_usuario != other.oid_usuario)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Usuario [oid_usuario=" + oid_usuario + ", nombre=" + nombre + ", oid_tabla_periodica="
				+ oid_tabla_periodica + "]";
	}
	
	
	
	

}
