package entities;

public class Elemento {
	
	private String nombreElemento;
	private String simbolo;
	private String tipoElemento;
	private int numeroAtomico;
	private float masaAtomica;
	private String urlVideo;
	public Elemento(String nombreElemento, String simbolo, String tipoElemento, int numeroAtomico, float masaAtomica,
			String urlVideo) {
		super();
		this.nombreElemento = nombreElemento;
		this.simbolo = simbolo;
		this.tipoElemento = tipoElemento;
		this.numeroAtomico = numeroAtomico;
		this.masaAtomica = masaAtomica;
		this.urlVideo = urlVideo;
	}
	public Elemento() {
		super();
	}
	public String getNombreElemento() {
		return nombreElemento;
	}
	public void setNombreElemento(String nombreElemento) {
		this.nombreElemento = nombreElemento;
	}
	public String getSimbolo() {
		return simbolo;
	}
	public void setSimbolo(String simbolo) {
		this.simbolo = simbolo;
	}
	public String getTipoElemento() {
		return tipoElemento;
	}
	public void setTipoElemento(String tipoElemento) {
		this.tipoElemento = tipoElemento;
	}
	public int getNumeroAtomico() {
		return numeroAtomico;
	}
	public void setNumeroAtomico(int numeroAtomico) {
		this.numeroAtomico = numeroAtomico;
	}
	public float getMasaAtomica() {
		return masaAtomica;
	}
	public void setMasaAtomica(float masaAtomica) {
		this.masaAtomica = masaAtomica;
	}
	public String getUrlVideo() {
		return urlVideo;
	}
	public void setUrlVideo(String urlVideo) {
		this.urlVideo = urlVideo;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int)masaAtomica;
		result = prime * result + ((nombreElemento == null) ? 0 : nombreElemento.hashCode());
		result = prime * result + numeroAtomico;
		result = prime * result + ((simbolo == null) ? 0 : simbolo.hashCode());
		result = prime * result + ((tipoElemento == null) ? 0 : tipoElemento.hashCode());
		result = prime * result + ((urlVideo == null) ? 0 : urlVideo.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Elemento other = (Elemento) obj;
		if (masaAtomica != other.masaAtomica)
			return false;
		if (nombreElemento == null) {
			if (other.nombreElemento != null)
				return false;
		} else if (!nombreElemento.equals(other.nombreElemento))
			return false;
		if (numeroAtomico != other.numeroAtomico)
			return false;
		if (simbolo == null) {
			if (other.simbolo != null)
				return false;
		} else if (!simbolo.equals(other.simbolo))
			return false;
		if (tipoElemento == null) {
			if (other.tipoElemento != null)
				return false;
		} else if (!tipoElemento.equals(other.tipoElemento))
			return false;
		if (urlVideo == null) {
			if (other.urlVideo != null)
				return false;
		} else if (!urlVideo.equals(other.urlVideo))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Elemento [nombreElemento=" + nombreElemento + ", simbolo=" + simbolo + ", tipoElemento=" + tipoElemento
				+ ", numeroAtomico=" + numeroAtomico + ", masaAtomica=" + masaAtomica + ", urlVideo=" + urlVideo + "]";
	}
	
	
	
	
}
