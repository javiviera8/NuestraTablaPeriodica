package entities;

public class TablaPeriodica {

	private int idTabla;
	private String elementos;
	
	public TablaPeriodica(int idElmentos, String elementos) {
		super();
		this.idTabla = idElmentos;
		this.elementos = elementos;
	}

	public TablaPeriodica() {
		super();
	}

	public int getIdElmentos() {
		return idTabla;
	}

	public void setIdElmentos(int idElmentos) {
		this.idTabla = idElmentos;
	}

	public String getElementos() {
		return elementos;
	}

	public void setElementos(String elementos) {
		this.elementos = elementos;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((elementos == null) ? 0 : elementos.hashCode());
		result = prime * result + idTabla;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TablaPeriodica other = (TablaPeriodica) obj;
		if (elementos == null) {
			if (other.elementos != null)
				return false;
		} else if (!elementos.equals(other.elementos))
			return false;
		if (idTabla != other.idTabla)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TablaPeriodica [idElmentos=" + idTabla + ", elementos=" + elementos + "]";
	}
	
	
	
	
	
}
